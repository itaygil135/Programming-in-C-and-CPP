#include <stdio.h>

#include "test_suite.h"
#include "pair.h"
#include "hashmap.h"
#include "test_pairs.h"
#include "hash_funcs.h"

#define         NUM_OF_PAIRS    50

void print_hashmap( hashmap *hash_map);
static pair **create_global_pairs()
{
    pair **pairs = malloc (sizeof (pair*)*NUM_OF_PAIRS);
    for (int j = 0; j < NUM_OF_PAIRS; ++j)
    {
        char key = (char) (j + 48);
        //even keys are capital letters, odd keys are digits
//        if (key % 2)
//        {
//            key += 17;
//        }
        int value = j+200;
        size_t hash =  hash_char((void *)&key);
        printf("j = %d key=%c  value=%d  hash=%d\n",j, key,value,hash);
        pairs[j] = pair_alloc (&key, &value, char_key_cpy, int_value_cpy, char_key_cmp,
                               int_value_cmp, char_key_free, int_value_free);
    }
    return pairs;
}

static void free_global_pairs(pair **pairs)
{
    // Free the pairs.
    for (int k_i = 0; k_i < NUM_OF_PAIRS; ++k_i)
    {
        pair_free ((void **) &pairs[k_i]);
    }
}

void test_demo(void)
{
    pair **pairs;
    pairs = create_global_pairs();
    // Create hash-map and inserts elements into it, using pair_char_int.h
    hashmap *map = hashmap_alloc (hash_char);
    for (int k = 0; k < NUM_OF_PAIRS; ++k)
    {
        hashmap_insert (map, pairs[k]);
    }
    //apply double_value on values where key is a digit
    char key_dig = '2', key_letter = 'D';
    printf ("map['2'] before apply if: %d, map['D'] before apply if: %d\n",
            *(int *) hashmap_at (map, &key_dig), *(int *) hashmap_at (map, &key_letter));
    int apply_if_res = hashmap_apply_if (map, is_digit, double_value);
    printf ("Number of changed values: %d\n", apply_if_res);
    printf ("map['2'] after apply if: %d, map['D'] after apply if: %d\n",
            *(int *) hashmap_at (map, &key_dig), *(int *) hashmap_at (map, &key_letter));
    // Free the pairs.
    free_global_pairs(pairs);
    // Free the hash-map.
    hashmap_free (&map);

}
/**
 * This function checks the hashmap_insert function of the hashmap library.
 * If hashmap_insert fails at some points, the functions exits with exit code 1.
 */
void test_hash_map_insert(void)
{
    float load_factor = 0;
    hashmap *map = NULL;
    pair **pairs = create_global_pairs();
    assert((map=hashmap_alloc(hash_char)) != NULL);
    for (int k = 0; k < NUM_OF_PAIRS; ++k)
    {
        assert(hashmap_insert (map, pairs[k]) == 1);
        printf("insert key = %c\n",*(char *)(pairs[k]->key));
        print_hashmap(map);
    }
    for (int k = 0; k < NUM_OF_PAIRS; ++k)
    {
         assert(hashmap_erase (map, pairs[k]->key) == 1);
        //  assert(hashmap_get_load_factor(map) == (float)(k+1)/(float)HASH_MAP_INITIAL_CAP);
    }

    // Free the hash-map.
    hashmap_free (&map);
    assert(map == NULL); // once hashmap was freed, the pointer should be null
    // Free the pairs.
    free_global_pairs(pairs);


}

/**
 * This function checks the hashmap_at function of the hashmap library.
 * If hashmap_at fails at some points, the functions exits with exit code 1.
 */
void test_hash_map_at(void)
{

}

/**
 * This function checks the hashmap_erase function of the hashmap library.
 * If hashmap_erase fails at some points, the functions exits with exit code 1.
 */
void test_hash_map_erase(void)
{

}

/**
 * This function checks the hashmap_get_load_factor function of the hashmap library.
 * If hashmap_get_load_factor fails at some points, the functions exits with exit code 1.
 */
void test_hash_map_get_load_factor(void)
{

}

/**
 * This function checks the HashMapGetApplyIf function of the hashmap library.
 * If HashMapGetApplyIf fails at some points, the functions exits with exit code 1.
 */
void test_hash_map_apply_if()
{

}
