#include "Dense.h"

//The clasee Dense
//======


//Constructor
Dense(w, bias, ActivationType)  /* Inits a new layer with given parameters.
									C'tor accepts 2 matrices and activation type
								*/

//Methods
//------


get_weights() /* Getter  Returns the weights of this layer forbids modification  */


get_bias()  /* Getter  Returns the bias of this layer forbids modification  */

get_activation()   /*  Getter Returns the activation function of this layer forbids modification  */



//Operators
//------

operator()  /*   Parenthesis
					Applies the layer on input and returns output matrix
					Layers operate as per section 3.1
						Matrix output = layer(input)
				*/