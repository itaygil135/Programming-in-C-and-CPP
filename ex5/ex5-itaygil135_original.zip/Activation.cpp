#include "Activation.h"


//The class Activation
//=========
//Constructor
//------------

Activation(ActivationType act_type)   /* Accepts an ActivationType enum with
										one of two legal values:
											RELU/SOFTMAX.
								Defines this instance's activation accordingly  */


//Methods
//--------
Getter get_activation_type()   // Returns this activation's type  (ReLU/Softmax)


//Operators
//---------
        () Parenthesis  /* Applies activation function on input. Does not change input.
						Matrix output = act(input)
						*/
