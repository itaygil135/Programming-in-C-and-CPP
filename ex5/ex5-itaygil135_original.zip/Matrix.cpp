#include "Matrix.h"



// the class  Matrix
//=======

Matrix::Matrix(int rows, int cols)
{
    dims.rows = rows;
    dims.cols = cols;
    p_matrix = new  float[dims.rows * dims.cols];

    //p_matrix = new.....
    //init all elements to 0;
}
Matrix::Matrix():Matrix(0,0){}
Matrix::Matrix(Matrix other):Matrix(other.dims.rows,other.dims.cols)
{
    //to copy all elemts inside as the same as other
}
Matrix::~Matrix()
{
    //free or delete al mempory alocated by the struct new
};


int Matrix::get_rows()// returns the amount of rows as int
{
    return dims.rows;
}
int Matrix::get_cols()// returns the amount of cols as int
{
    return dims.cols;
};
Matrix& Matrix::transpose() /* Transforms a matrix into its transpose matrix.
                         (A.transpose())ij = Aji Supports function calling concatenation.
                         e.g.
                            Matrix a(5, 4), b(4, 5);
                            a.transpose(); // a.get_rows == 4,
                            a.get_cols == 5
                            b.transpose().transpose(); // b is same as before*/
{
    //firstpf all update inside matrix
    int temp  = dims.cols;
    dims.cols = dims.rows;
    dims.rows = temp;
    return *this;
};
Matrix& Matrix::vectorize()/* Transforms a matrix into a column vector.
                    Supports function calling concatenation.
                    e.g.:
                        Matrix m(5, 4); ...
                        m.vectorize();
                        m.get_cols() == 1
                        m.get_rows() == 20
                        */
{
    //firstpf all update inside matrix
    dims.rows = get_cols()*get_rows();
    dims.cols = 1;
    return *this;
};
void Matrix::plain_print() /*  Prints matrix elements, no return value.
                        Prints space after each element (including last element in row)
                        Prints newline after each row (including last row) */
{
  //to print as needed;
};
Matrix& Matrix::dot(Matrix other) /* Returns a matrix which is the dot
                        product of this matrix and another matrix m :
                        for all i, j : (A.dot(B))ij = Aij · Bij
                    */
        {
    // first of all need to make sure that its the same dimentions of matrixs
    //update by multi
    return *this;
        };
float Matrix::norm() 				/*Returns the Frobenius norm of the
							given matrix : A.norm() = ????  see the PDF !!!!
							i, j
							A2
							ij

*/
{float result = 0;
//calculate result
    return result;
};
void Matrix::read_binary_file(istream file, Matrix& mat) /*Fills matrix elements as per section
							2.3.Has to read input stream fully,
							otherwise it's an error (don't trust the
							user to validate it).
						*/
{
    //read the file and update mat and in an error should sheck what to do;
};

//Operators
//---------
Matrix& Matrix::operator+(Matrix rhs)
{
    //update
  return *this;
};
Matrix& Matrix::operator=(Matrix rhs)
        {
            // is the same mat return *this;
            dims.cols = rhs.get_cols();
            dims.rows = rhs.get_rows();

            // free p_matrix;
            //  allocate new mem (p_matrix) at the size rows*cols;
            //  for i,j in rhs, copy rhs[i,j] into m_matrix[i,j]



            return *this;
        };

Matrix& Matrix::operator*(Matrix rhs)
{
    //alocate a new p_matrix at the size of dims.rows and rhs.coles and update
    // do not forget to free (delete) the original memory that p_matrix point to
    // it and than chnge dims.coles to rhs.coles
    return *this;
};
Matrix& Matrix::operator*(int scalar)  /*     multiplication on the right
                                Matrix m; flooat c; -> m * c */
{
}
operator * Scalar  /*    multiplication onthe left Matrix
                           m; float c; -> c * m  */
        {

        };
operator+= /*Matrix addition  accumulation Matrix
                       a, b;->a += b */
operator() /* Parenthesisindexing
                          For i, j indices, Matrix m :
                             m(i, j) will return the i, j element in the matrix  */
operator[] /*Brackets indexing For i index, Matrix m :
                        m[i] will return the i'th element (section 3.2) */
operator<<   /*Output stream Pretty export of matrix as per section 2.4 */