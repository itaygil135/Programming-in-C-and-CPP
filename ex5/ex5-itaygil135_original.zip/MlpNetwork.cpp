#include "MlpNetwork.h"


// the class MlpNetwork
//=====================

// constrator
//-----------
MlpNetwork(weights[], biases[])   /*
                                    Accepts 2 arrays, size 4 each.
									one for weights and one for biases.
									constructs the network described (sec. 2.2)
                                  */

// operator
//---------
operator()  /* Parenthesis Applies the entire network on input
					returns digit struct
					MlpNetwork m(...);
					Digit output = m(img);
					*/
