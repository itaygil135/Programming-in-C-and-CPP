#include "Activation.h"


void expSumAndChangeVec(Matrix& mat, const int vecCol, const int vecLen, const int matCols);

Activation::Activation(ActivationType act_type)
{
    act_type = act_type;
}

ActivationType Activation::get_activation_type()
{
    return this->act_type;
}


Matrix Activation::operator()(const Matrix& input)
{

    int cols = input.get_cols();
    Matrix new_mat(input);
    if (act_type == RELU)
    {
        for (int j = 0; j < cols; j++)
        {
            relu_function(new_mat, j);
        }
    }
    else if (act_type == SOFTMAX)
    {
        for (int j = 0; j < cols; j++)
        {
            softmax_function(new_mat, j);
        }
    }
    return new_mat;
}


void Activation::relu_function(Matrix &mat, int index)
{
    int rows = mat.get_rows(); int cols = mat.get_cols();
    for (int i = 0; i < rows; i++)
    {
        if (mat(i, index) < 0)
        {
            mat[i * cols + index] = 0;
        }
    }
}
void Activation::softmax_function(Matrix& mat, int index)
{
    int rows = mat.get_rows(); int cols = mat.get_cols();
    expSumAndChangeVec(mat, index, rows, cols);
}

/**
 * @brief Calculates the exp sum for each coordinate and change each col by the solution
 * @param mat
 * @param vecCol
 * @param vecLen
 * @param matCols
 */
void expSumAndChangeVec(Matrix& mat, const int vecCol, const int vecLen, const int matCols)
{
    float sum = 0;
    for (int i = 0; i < vecLen; i++)
    {
        mat[i * matCols + vecCol] = std::exp(mat[i * matCols + vecCol]);
        sum += mat[i * matCols + vecCol];
    }
    float expSum = ((float)1) / sum;
    for (int i = 0; i < vecLen; i++)
    {
        mat[i * matCols + vecCol] = mat[i * matCols + vecCol] * expSum;
    }
}