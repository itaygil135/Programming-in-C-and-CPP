#include "Dense.h"
#include "Activation.h"


Dense::Dense( Matrix  w,  Matrix  bias, ActivationType ActivationType):
    weights(w),
    bias(bias),
    activation_obj(ActivationType) 
{}

Matrix Dense::get_weights()
{
    return this->weights;
}

Matrix Dense::get_bias()
{
    return this->bias;
}

Activation Dense::get_activation() const
{
    return this->activation_obj;
}

Matrix Dense::operator()( Matrix& input_mat)
{
    Matrix result;

    result = input_mat.dot(weights);
    result += bias;

    // what is going on with the memory allocation for the result once the activation_obj() is called?

    result = activation_obj(result);


    return result;
}

