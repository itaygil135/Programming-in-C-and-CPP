#ifndef C___PROJECT_DENSE_H
#define C___PROJECT_DENSE_H

#include "Activation.h"

// implement class Dense here...

class Dense
{
private:
    Matrix weights;
    Matrix bias;
    Activation activation_obj;


public:

    //Constructor 
    Dense( Matrix  w,  Matrix  bias, ActivationType ActivationType); 
                                        /* Inits a new layer with given parameters.
                                        C'tor accepts 2 matrices and activation type
                                    */

    Matrix get_weights(); /* Getter  Returns the weights of this layer forbids modification  */


    Matrix get_bias(); /* Getter  Returns the bias of this layer forbids modification  */

    Activation get_activation() const;  /*  Getter Returns the activation function of this layer forbids modification  */

    Matrix operator()( Matrix& input_mat);  /*   Parenthesis
                            Applies the layer on input and returns output matrix
                            Layers operate as per section 3.1
                                Matrix output = layer(input)
                        */


};

#endif //C___PROJECT_DENSE_H
