#ifndef C___PROJECT_DENSE_H
#define C___PROJECT_DENSE_H

#include "Activation.h"

// implement class Dense here...

#endif //C___PROJECT_DENSE_H
